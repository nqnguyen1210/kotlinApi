package com.example.photo.ui.list

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.photo.BR
import com.example.photo.R
import com.example.photo.databinding.ActivityPhotosBinding
import com.example.photo.extension.showAction
import com.example.photo.extension.showError
import com.example.photo.extension.startAnimatedActivity
import com.example.photo.local.Photo
import com.example.photo.remote.PhotosResponseCallback
import com.example.photo.ui.detail.DetailPhotoActivity
import org.jetbrains.anko.alert
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.noButton
import org.jetbrains.anko.sdk27.coroutines.onClick
import org.jetbrains.anko.yesButton

class PhotosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhotosBinding

    private val viewModel: PhotosViewModel by lazy { ViewModelProviders.of(this).get(PhotosViewModel::class.java) }

    private var photosAdapter = PhotosAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_photos)
        binding.setVariable(BR.viewModel, viewModel)
        binding.setLifecycleOwner(this)

        setupAdapter()
        //setupFab()
        setupRecyclerView()
        setupSwipeRefreshLayout()
    }

    private fun setupAdapter() {
        viewModel.photos.observe(this, Observer {
            photosAdapter.submitList(it)
        })


        photosAdapter.apply {
            onClick = { startAnimatedActivity(intentFor<DetailPhotoActivity>("id" to it.id)) }
            onLongClick = { showDeletePopup(it) }
        }

    }

    /*
    private fun setupFab() {
        binding.fab.onClick { startAnimatedActivity(intentFor<CreatePhotoActivity>()) }
    }*/


    private fun setupRecyclerView() {
        binding.recyclerView.apply {
            addItemDecoration(DividerItemDecoration(this@PhotosActivity, DividerItemDecoration.VERTICAL))
            layoutManager = LinearLayoutManager(this@PhotosActivity)
            adapter = photosAdapter
        }
    }


    private fun setupSwipeRefreshLayout() {
        binding.swipeRefreshLayout.apply {

            fun refresh() {
                isRefreshing = true
                viewModel.refresh(object: PhotosResponseCallback {
                    override fun onSuccess() {
                        binding.root.showAction(getString(R.string.photos_loaded))
                        isRefreshing = false
                    }

                    override fun onError(throwable: Throwable) {
                        binding.root.showError(getString(R.string.photos_loading_error))
                        isRefreshing = false
                    }
                })
            }

            setOnRefreshListener { refresh() }
            post { refresh() }
        }
    }

    private fun showDeletePopup(photo: Photo) {
        alert(getString(R.string.delete_photo_warning, photo.title)) {
            yesButton { viewModel.delete(photo) }
            noButton { }
        }.show()
    }
}