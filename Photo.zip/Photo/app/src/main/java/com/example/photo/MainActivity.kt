package com.example.photo

import android.app.Application
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.photo.local.Photo
import com.example.photo.local.PhotoRepository

class MainActivity : Application() {

    override fun onCreate() {
        super.onCreate()

        PhotoRepository.initialize(this)

        val photos = listOf(
            Photo(
                albumId = 1,
                id = 1,
                title = "Photo 1",
                url = ""
            ),

            Photo(
                albumId = 1,
                id = 2,
                title = "Photo 2",
                url = ""
            ),

            Photo(
                albumId = 1,
                id = 3,
                title = "Photo 3",
                url = ""
            )
        )

        PhotoRepository.insertAll(photos)
    }
}
