package com.example.photo.ui.list

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.photo.local.Photo
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import com.example.photo.R
import com.example.photo.BR

class PhotosAdapter: ListAdapter<Photo, PhotosAdapter.PhotoViewHolder>(PhotoDiffCallback()) {

    var onClick: ((item: Photo) -> Unit)? = null
    var onLongClick: ((item: Photo) -> Unit)? = null

    override fun getItemViewType(position: Int): Int = R.layout.item_photo

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val viewDataBinding: ViewDataBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.context), viewType, parent, false)
        return PhotoViewHolder(viewDataBinding)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        holder.bind(getItem(position), object: OnPhotoClickListener {
            override fun onItemClick(photo: Photo) {
                onClick?.invoke(photo)
            }

            override fun onItemLongClick(photo: Photo): Boolean {
                onLongClick?.invoke(photo)
                return true
            }
        })
    }

    class PhotoDiffCallback: DiffUtil.ItemCallback<Photo>() {

        override fun areContentsTheSame(oldItem: Photo, newItem: Photo): Boolean = oldItem == newItem

        override fun areItemsTheSame(oldItem: Photo, newItem: Photo): Boolean = oldItem.id == newItem.id
    }

    class PhotoViewHolder(private val viewDataBinding: ViewDataBinding): RecyclerView.ViewHolder(viewDataBinding.root) {

        fun bind(photo: Photo, OnPhotoClickListener: OnPhotoClickListener) {
            viewDataBinding.setVariable(BR.photo, photo)
            viewDataBinding.setVariable(BR.listener, OnPhotoClickListener)
            viewDataBinding.executePendingBindings()
        }
    }

    interface OnPhotoClickListener {

        fun onItemClick(photo: Photo)

        fun onItemLongClick(photo: Photo): Boolean

    }
}