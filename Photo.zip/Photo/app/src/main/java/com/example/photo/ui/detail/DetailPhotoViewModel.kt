package com.example.photo.ui.detail

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.example.photo.local.Photo
import com.example.photo.local.PhotoRepository

class DetailPhotoViewModel(application: Application): AndroidViewModel(application) {

    var photoId: MutableLiveData<Int> = MutableLiveData()

    var photo: LiveData<Photo> = Transformations.switchMap(photoId) { id -> PhotoRepository.getById(id) }
}