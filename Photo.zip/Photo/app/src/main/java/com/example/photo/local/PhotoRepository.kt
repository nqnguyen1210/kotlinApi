package com.example.photo.local

import android.app.Application
import android.util.Log
import androidx.lifecycle.LiveData
import com.example.photo.remote.PhotoResponse
import com.example.photo.remote.PhotoService
import com.example.photo.remote.PhotosResponseCallback
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import org.jetbrains.anko.doAsync
import java.util.*

object PhotoRepository {

    private lateinit var database: PhotoDatabase

    private lateinit var photoDao: PhotoDao

    private val service = PhotoService.create()

    fun initialize(application: Application) {
        database =
            PhotoDatabase.buildInstance(application)
        photoDao = database.photoDao()
    }

    //region locale

    fun insertAll(photos: List<Photo>) = doAsync {
        photoDao.insertAll(photos)
        Log.d("photoRepository","inserting photos: $photos")
    }

    fun insert(photo: Photo) =
        insertAll(listOf(photo))

    fun delete(photo: Photo) = doAsync { photoDao.delete(photo) }

    fun getById(id: Int): LiveData<Photo> = photoDao.getById(id)

    fun getAll(): LiveData<List<Photo>> = photoDao.getAllLive()

    //endregion

    //region remote

    fun downloadPhotos(callback: PhotosResponseCallback) {
        service.getAllPhotos()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeBy(
                onNext = { photosList -> insertAll(photosList.map { photoResponse -> photoResponseToPhoto(photoResponse)}) },
                onComplete = { callback.onSuccess() },
                onError = { callback.onError(it) }
            )
    }

    private fun photoResponseToPhoto(photoResponse: PhotoResponse): Photo = Photo(
        albumId = photoResponse.albumId,
        id = photoResponse.id,
        title = photoResponse.title,
        url = photoResponse.url
    )

    //endregion
}