package com.example.photo.remote

interface PhotosResponseCallback {

    fun onSuccess()

    fun onError(throwable: Throwable)
}