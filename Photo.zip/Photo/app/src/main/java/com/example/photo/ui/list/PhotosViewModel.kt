package com.example.photo.ui.list

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.photo.local.Photo
import com.example.photo.local.PhotoRepository
import com.example.photo.remote.PhotosResponseCallback

class PhotosViewModel(application: Application): AndroidViewModel(application) {

    var photos: LiveData<List<Photo>> = PhotoRepository.getAll()

    fun delete(photo: Photo) {
        PhotoRepository.delete(photo)
    }

    fun refresh(callback: PhotosResponseCallback) {
        PhotoRepository.downloadPhotos(callback)
    }
}